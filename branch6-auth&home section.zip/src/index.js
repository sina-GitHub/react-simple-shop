import React from 'react';
import ReactDOM from 'react-dom';

import Apollo from './Apollo';
import './components/i18';

ReactDOM.render(<Apollo />, document.getElementById('root'));
