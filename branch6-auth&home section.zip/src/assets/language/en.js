export default {
  translation: {
    "hello world": "Hello World",
    home: "Home",
    search: "search...",
    about: "about",
    users: "users",
    "search the user": "search the user",
    wip: "Working In Progress",
    "not found": "The requested information was not found...",
    login: "login",
    register: "register",
  },
};
