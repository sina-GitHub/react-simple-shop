export default {
  translation: {
    "hello world": "سلام دنیا",
    home: "خانه",
    search: "...جستجو",
    about: "درباره",
    users: "کاربران",
    "search the user": "جستجوی کاربر مورد نظر",
    wip: "در درست اجرا",
    "not found": "...اطلاعات مورد نظر یافت نشد",
    login: "ورود",
    register: "ثبت نام",
  },
};
